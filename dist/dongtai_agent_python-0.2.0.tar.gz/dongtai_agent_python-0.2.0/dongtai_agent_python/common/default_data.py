
defaultApiData = {
    "detail": {
        "agent_id": 0,
        "http_protocol": "HTTP/1.1",
        "context_path": "",
        "pool": [],
        "http_client_ip": "127.0.0.1",
        "http_uri": "/vul/cmd-001",
        "http_url": "http://localhost:8080/vul/cmd-001",
        "http_secure": False,
        "app_name": "",
        "http_replay_request": False,
        "http_method": "GET",
        "http_req_header": "aG9zdDpsb2NhbG",
        "http_body": "",
        "http_res_body": "uid=501(shengnanwu) gid=20(staff)",
        "http_scheme": "http",
        "http_query_string": "cmd=id",
        "http_res_header": "SFRUUC8xLjEgMjAwClgtQ29ud"
    },
    "type": 36
}


