
defaultApiData = {
    "detail": {
        "agentId": 0,
        "uri": "/vul/cmd-001",
        "url": "http://localhost:8080/vul/cmd-001",
        "protocol": "HTTP/1.1",
        "contextPath": "",
        "pool": [],
        "language":"PYTHON",
        "clientIp": "127.0.0.1",
        "secure": False,
        "appName": "",
        "replayRequest": False,
        "method": "GET",
        "reqHeader": "aG9zdDpsb2NhbG",
        "reqBody": "",
        "resBody": "uid=501(shengnanwu) gid=20(staff)",
        "scheme": "http",
        "resHeader": "SFRUUC8xLjEgMjAwClgtQ29ud"
    },
    "type": 36
}


