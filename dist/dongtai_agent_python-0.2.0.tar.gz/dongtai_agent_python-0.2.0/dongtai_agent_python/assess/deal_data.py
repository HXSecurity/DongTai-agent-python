# hook 参数处理 且 处理污点池
import dongtai_agent_python.global_var as dt_global_var
from dongtai_agent_python.common import origin
from dongtai_agent_python.global_var import _global_dt_dict
from dongtai_agent_python.common.content_tracert import method_pool_data, dt_tracker_get, dt_tracker_set, come_in, \
    deal_args


def wrapData(result, origin_cls, _fcn, signature=None, source=False, comeData=None):
    dt_data_args = dt_tracker_get("dt_data_args")
    if dt_data_args is None:
        return result

    if comeData is None:
        comeData = []

    dt_open_pool = _global_dt_dict.get("dt_open_pool")
    if not dt_open_pool:
        return result

    # 污点池
    dt_global_var.dt_set_value("dt_open_pool", False)

    # 获取source点
    taint_in = []
    if source:
        can_upload = 1
        # 入参入池 id
        end_args = deal_args(comeData)
        for one in end_args:
            dt_data_args = come_in(one, dt_data_args)
            origin.list_append(taint_in, one)
    else:
        can_upload = 0

        if len(dt_data_args) != 0:
            # 入参入池 id
            end_args = deal_args(comeData)
            for two in end_args:
                if two in dt_data_args:
                    # hook 当前方法 且 将结果值存入污点池
                    can_upload = 1
                    if two not in taint_in:
                        origin.list_append(taint_in, two)

    if can_upload == 1:
        # 当前方法type为2、3， callerMethod not in 2、3类其他方法中

        dt_data_args = come_in(result, dt_data_args)
        dt_tracker_set("dt_data_args", dt_data_args)
        method_pool_data(origin_cls, _fcn, comeData, taint_in, result, source=source, signature=signature)

    dt_global_var.dt_set_value("dt_open_pool", True)

    return result
