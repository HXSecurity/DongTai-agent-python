import dongtai_agent_python.global_var as dt_global_var

dt_global_var._init()
dt_global_var.get_config_data()